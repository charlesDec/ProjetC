
;

extern void printChar(char);

int main()
{
	printChar('v');
	return 0;
}
