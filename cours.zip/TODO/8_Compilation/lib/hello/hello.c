#include"hello.h"
#include<stdio.h>

void helloFromC()
{
	printf("HelloFromC\n");
}


