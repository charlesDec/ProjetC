#ifndef MAT_H
#define MAT_H

int sum(int a, int b);


#endif
