
extern int sum(int,int);
extern void helloFromC();

int main()
{
	int a = sum(5,6);
	helloFromC();
	return 0;
}
