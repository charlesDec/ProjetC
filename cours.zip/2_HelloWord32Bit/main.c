
#include"stdio.h"

int main()
{
	
	printf("HelloWord!\n");
	
	return 0;
}
